export const HOME = "/products";
export const LOG_IN = "/login";
export const SHOPPING_CART = "/cart";
