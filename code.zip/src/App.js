import "./App.css";
import Products from "./components/Products";
import * as ROUTES from "./constants/routes";

function App() {
  return (
    <div className="App">
      <Products />
    </div>
  );
}

export default App;
